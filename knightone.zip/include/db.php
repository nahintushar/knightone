<?php
session_start();
$db = mysqli_connect('localhost','root','','knightone') or die("database not connected !");
 ?>
