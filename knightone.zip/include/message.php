
  <?php
  print_r($_POST);
  require_once 'db.php';
  if (isset($_POST['ok'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $insert = "INSERT INTO 'contact_message' ('name','email','subject','message') VALUES ('$name','$email','$subject','$message')";

    $q = mysqli_query($db, $insert);
    header('location:../index.php');

  }
 ?>
