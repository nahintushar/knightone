<?php
require_once '../include/db.php';

if (isset($_POST['update-feature-image'])) {

  $old_img = $_POST['old_img'];

  $fileName = $_FILES['feature_img']['name'];
  $fileTempName = $_FILES['feature_img']['tmp_name'];

  $fileExt = explode('.', $fileName);
  $fileActualExt = strtolower(end($fileExt));

  $allowed = array('jpg', 'jpeg', 'png', 'pdf');

  if (in_array($fileActualExt, $allowed)) {
    $fileNewName = uniqid('', true).".".$fileActualExt;
    $fileDestination = '../assets/img/' .$fileNewName;
    $upload = move_uploaded_file($fileTempName, $fileDestination);

    if ($upload !='') {
      $query = "UPDATE features_image SET image='$fileNewName' WHERE 1";
      $result = mysqli_query($db, $query);

          move_uploaded_file($fileTempName, $fileDestination);
          unlink('../assets/img/' .$old_img);

          header('location:features.php');
        }
      else {
        echo "something wrong";
      }

  }else {
    echo "you can not upload this type of file";
  }

}
 ?>
