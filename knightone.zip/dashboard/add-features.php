<?php
require_once '../include/db.php';

if (isset($_POST['add-features'])) {

  $icon = mysqli_real_escape_string($db,$_POST['icon']);
  $title = mysqli_real_escape_string($db,$_POST['title']);
  $subtitle = mysqli_real_escape_string($db,$_POST['subtitle']);

  $insert = "INSERT INTO features (icon, title, subtitle) VALUES ('$icon', '$title', '$subtitle')";
  $run = mysqli_query($db, $insert);


    header('location:features.php');

}

 ?>
