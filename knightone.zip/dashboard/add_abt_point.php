<?php
require_once '../include/db.php';

if (isset($_POST['add-abt-point'])) {

  $point = mysqli_real_escape_string($db,$_POST['abt_point']);

  $insert = "INSERT INTO about_point (abt_point_title) VALUES ('$point')";
  $run = mysqli_query($db, $insert);


    header('location:about.php');


}
 ?>
