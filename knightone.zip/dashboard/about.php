<?php
include 'inc/header.php'
?>

<?php
$query = "SELECT * FROM about_title";
$run = mysqli_query($db,$query);
$about_title_data = mysqli_fetch_assoc($run);
 ?>

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="about.php">About Title</a></li>
            </ol>
          </div>
        </div>
        <!-- page start-->

        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading" style="background:black; color:white; font-weight:700; font-size:20px">
                Update About
              </header>
              <div class="panel-body">
                <form role="form" action="update-about.php" method="post">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Title</label>
                    <input type="text" name="title" class="form-control" id="exampleInputEmail1" placeholder="Enter Title" value="<?=$about_title_data['abt_title']?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Subtitle</label>
                    <input type="text" name="subtitle" class="form-control" id="exampleInputPassword1" placeholder="Subtitle" value="<?=$about_title_data['abt_subtitle']?>">
                  </div>
                  <!-- <div class="form-group">
                    <label for="exampleInputPassword1">Subtitle</label>
                    <input type="text" name="subtitle" class="form-control" id="exampleInputPassword1" placeholder="Subtitle" value="<?=$about_title_data['abt_subtitle_one']?>">
                  </div> -->
                  <div class="form-group">
                    <label for="exampleInputPassword1">Details</label>
                     <textarea name="subtitleone" class="form-control" rows="8" cols="80"> <?=$about_title_data['abt_subtitle_one']?> </textarea>
                  </div>
                  <button type="submit" name="update-about" class="btn btn-primary">Save Change</button>
                </form>

              </div>
            </section>
          </div>
        </div>


        <div class="row">

          <div class="col-lg-6">
            <section class="panel" >
              <header class="panel-heading" style="background:black; color:white; font-weight:700; font-size:20px">
                About Point
              </header>
              <br>

              <table class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                    <th>#</th>
                    <th>About Point Name</th>
                    <th>Action</th>
                  </tr>

                  <?php
                  $query = "SELECT * FROM about_point";
                  $run = mysqli_query($db,$query);
                  $c = 1;
                  while ($about_point_data = mysqli_fetch_assoc($run)) {
                    ?>

                    <tr>
                      <td><?=$c?></td>
                      <td><?=$about_point_data['abt_point_title'] ?></td>
                      <td>
                        <div class="btn-group">
                          <a class="btn btn-danger" href="delete-abt-point.php?id=<?=$about_point_data['id'] ?>" title="Bootstrap 3 themes generator"> DELETE</a>
                        </div>
                      </td>
                    </tr>

                  <?php
                  $c++;
                  }
                   ?>

                </tbody>
              </table>
            </section>
          </div>

          <div class="col-lg-6">
            <section class="panel">
              <header class="panel-heading" style="background:black; color:white; font-weight:700; font-size:20px">
                Add About Point
              </header>
              <div class="panel-body">
                <form role="form" action="add_abt_point.php" method="post">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Add About Point</label>
                    <input type="text" name="abt_point" class="form-control" id="exampleInputEmail1" placeholder="Add About Point">
                  </div>
                  <button type="submit" name="add-abt-point" class="btn btn-primary">Add</button>
                </form>

              </div>
            </section>
          </div>

        </div>

        <!-- page end-->
      </section>
    </section>
    <!--main content end-->

    <?php include 'inc/footer.php' ?>
